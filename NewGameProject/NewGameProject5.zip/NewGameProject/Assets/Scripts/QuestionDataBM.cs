﻿using UnityEngine;
using System.Collections;
using System;

[System.Serializable]
public class QuestionDataBM
{
    public string questionTextBM;
    public AnswerDataBM[] answersBM;

    public static implicit operator QuestionDataBM(QuestionData v)
    {
        throw new NotImplementedException();
    }
}