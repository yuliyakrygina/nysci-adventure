﻿using UnityEngine;
using System.Collections;
using System;

[System.Serializable]
public class AnswerDataBM
{
    public string answerText;
    public bool isCorrectBM;

    public static implicit operator AnswerDataBM(AnswerData v)
    {
        throw new NotImplementedException();
    }
}