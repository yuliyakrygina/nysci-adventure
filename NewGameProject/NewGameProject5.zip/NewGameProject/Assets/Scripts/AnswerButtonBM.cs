﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class AnswerButtonBM : MonoBehaviour
{

    public Text answerText;

    private AnswerDataBM answerData;
    private GameController gameController;
    private bool AnswerButtonClickedBM;


    // Use this for initialization
    void Start()
    {
        gameController = FindObjectOfType<GameController>();
    }

    public void Setup(AnswerData data)
    {
        answerData = data;
        answerText.text = answerData.answerText;
    }


    public void HandleClick()
    {
        gameController.AnswerButtonClicked(answerData.isCorrectBM); //problem 
    }

    internal void Setup(AnswerDataBM answerDataBM)
    {
        throw new NotImplementedException();
    }
}