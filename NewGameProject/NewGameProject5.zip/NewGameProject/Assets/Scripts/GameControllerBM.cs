﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System;

public class GameController1 : MonoBehaviour
{
   

    public Text questionDisplayTextBM;
    public Text scoreDisplayTextBM;
    public Text timeRemainingDisplayTextBM;
    public SimpleObjectPool answerButtonObjectPoolBM;
    public Transform answerButtonParentBM;
    public GameObject questionDisplayBM;
    public GameObject roundEndDisplayBM;

    private DataController dataControllerBM;
    private RoundData currentRoundDataBM;
    private QuestionData[] questionPoolBM;

    private bool isRoundActiveBM;
    private float timeRemainingBM;
    private int questionIndexBM;
    private int playerScoreBM;
    private List<GameObject> answerButtonGameObjects = new List<GameObject>();
    


    // Use this for initialization

    internal class GameControllerBM
    {
        internal void AnswerButtonClickedBM(bool isCorrect)
        {
            throw new NotImplementedException();
        }
    }


    void Start()
    {
        dataControllerBM = FindObjectOfType<DataController>();
        currentRoundDataBM = dataControllerBM.GetCurrentRoundData();
        questionPoolBM = currentRoundDataBM.questions;
        timeRemainingBM = currentRoundDataBM.timeLimitInSeconds;
        UpdateTimeRemainingDisplay();

        playerScoreBM = 0;
        questionIndexBM = 0;

        ShowQuestionBM();
        isRoundActiveBM = true;

    }

    private void ShowQuestionBM()
    {
        RemoveAnswerButtons();
        QuestionDataBM questionData = questionPoolBM[questionIndexBM];
        questionDisplayTextBM.text = questionData.questionTextBM;

            for (int i = 0; i < questionData.answersBM.Length; i++)
            {
                GameObject answerButtonGameObject = answerButtonObjectPoolBM.GetObject();
                answerButtonGameObjects.Add(answerButtonGameObject);
                answerButtonGameObject.transform.SetParent(answerButtonParentBM);

                AnswerButtonBM answerButton = answerButtonGameObject.GetComponent<AnswerButtonBM>(); 
                answerButton.Setup(questionData.answersBM[i]);
            }
        }

        private void ShowQuestion()
        {
            RemoveAnswerButtons();
            QuestionDataBM questionDataBM = questionPoolBM[questionIndexBM];
            questionDisplayTextBM.text = questionDataBM.questionTextBM;


            for (int i = 0; i < questionDataBM.answersBM.Length; i++)
            {
                GameObject answerButtonGameObject = answerButtonObjectPoolBM.GetObject();
                answerButtonGameObjects.Add(answerButtonGameObject);
                answerButtonGameObject.transform.SetParent(answerButtonParentBM);

                AnswerButtonBM answerButton = answerButtonGameObject.GetComponent<AnswerButtonBM>(); 
                answerButton.Setup(questionDataBM.answersBM[i]);
            }
        }



        private void RemoveAnswerButtons()
        {
            while (answerButtonGameObjects.Count > 0)
            {
                answerButtonObjectPoolBM.ReturnObject(answerButtonGameObjects[0]);
                answerButtonGameObjects.RemoveAt(0);
            }
        }

        public void AnswerButtonClicked(bool isCorrect)
        {
            if (isCorrect)
            {
                playerScoreBM += currentRoundDataBM.pointsAddedForCorrectAnswer;
                scoreDisplayTextBM.text = "Score: " + playerScoreBM.ToString();
            }

            if (questionPoolBM.Length > questionIndexBM + 1)
            {
                questionIndexBM++;
                ShowQuestionBM();
            }
            else
            {
                EndRoundBM();
            }

        }



        public void EndRoundBM()
        {
            isRoundActiveBM = false;

            questionDisplayBM.SetActive(false);
            roundEndDisplayBM.SetActive(true);
        }



        public void ReturnToMenu()
        {
            SceneManager.LoadScene("MapScreen");
        }

        private void UpdateTimeRemainingDisplay()
        {
            timeRemainingDisplayTextBM.text = "Time: " + Mathf.Round(timeRemainingBM).ToString();
        }

        // Update is called once per frame
        void Update()
        {
            if (isRoundActiveBM)
            {
                timeRemainingBM -= Time.deltaTime;
                UpdateTimeRemainingDisplay();

                if (timeRemainingBM <= 0f)
                {
                    EndRoundBM();
                }

            }




        }
    }

